package com.deva.chat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PdfChatApplicationTests {

	@Test
	void contextLoads() {
	}

}
